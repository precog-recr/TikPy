#%%
from newspaper import Article
from bs4 import BeautifulSoup
import requests
import json
import os
import time

